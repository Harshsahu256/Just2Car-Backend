import carModel from "../Models/car.model.js";
import User from "../Models/user.model.js";
import { uploadFileToSpaces, deleteFileFromSpaces } from "../Services/s3Service.js";
import { ApiError } from "../Utils/apiError.js";
import { STATUS_CODES } from "../Utils/status.codes.messages.js";
import mongoose from 'mongoose'

export const getUserProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id)

      .select("-password");

    if (!user) return res.status(404).json({ message: "User not found" });

    res.status(200).json({
      message: "User profile fetched successfully",
      data: user,
    });
  } catch (err) {
    next(err);
  }
};




// export const updateUserProfile = async (req, res, next) => {
//   try {
//     const { fullName, email, phone, country, state, city, pincode } = req.body;

//     const updateData = { fullName, email, phone, country, state, city, pincode };

//     // Handle profile image
//     if (req.file) {
//       const profileImage = await uploadFileToSpaces(req.file, "profile-images");
//       updateData.profileImage = profileImage;
//     }

//     const updatedUser = await User.findByIdAndUpdate(req.user.id, updateData, {
//       new: true,
//     }).select("-password");

//     res.status(200).json({
//       message: "Profile updated successfully",
//       data: updatedUser,
//     });
//   } catch (err) {
//     next(err);
//   }
// };

// export const updateUserProfile = async (req, res, next) => {
//   try {
//     const { fullName, email, phone, country, state, city, pincode } = req.body;

//     // Helper function: convert string to ObjectId if valid, else null
//     const toObjectIdOrNull = (value) => {
//       if (!value || value === "") return null;
//       return mongoose.Types.ObjectId.isValid(value) ? mongoose.Types.ObjectId(value) : null;
//     };

//     const updateData = {
//       fullName,
//       email,
//       phone,
//       pincode,
//       country: toObjectIdOrNull(country),
//       state: toObjectIdOrNull(state),
//       city: toObjectIdOrNull(city),
//     };

//     // remove undefined values
//     Object.keys(updateData).forEach(
//       (key) => updateData[key] === undefined && delete updateData[key]
//     );

//     // Handle profile image
//     if (req.file) {
//       updateData.profileImage = await uploadFileToSpaces(
//         req.file,
//         "profile-images"
//       );
//     }

//     const updatedUser = await User.findByIdAndUpdate(
//       req.user.id,
//       updateData,
//       { new: true }
//     ).select("-password");

//     res.status(200).json({
//       message: "Profile updated successfully",
//       data: updatedUser,
//     });
//   } catch (err) {
//     next(err);
//   }
// };
export const updateUserProfile = async (req, res, next) => {
  try {
    const { fullName, email, phone } = req.body; // Removed pincode, country, state, city

    const updateData = {
      fullName,
      email,
      phone,
    };

    // Remove undefined values
    Object.keys(updateData).forEach(
      (key) => updateData[key] === undefined && delete updateData[key]
    );

    // Handle profile image
    if (req.file) {
      updateData.profileImage = await uploadFileToSpaces(
        req.file,
        "profile-images"
      );
    }

    const updatedUser = await User.findByIdAndUpdate(
      req.user.id,
      updateData,
      { new: true }
    ).select("-password");

    res.status(200).json({
      message: "Profile updated successfully",
      data: updatedUser,
    });
  } catch (err) {
    next(err);
  }
};






export const updateUserPassword = async (req, res, next) => {
  try {
    const { oldPassword, newPassword } = req.body;

    const user = await User.findById(req.user.id).select("+password");

    const isMatch = await user.comparePassword(oldPassword);
    if (!isMatch) return res.status(400).json({ message: "Old password is incorrect" });

    user.password = newPassword;
    await user.save();

    res.status(200).json({
      message: "Password updated successfully",
    });
  } catch (err) {
    next(err);
  }
};


export const deleteUserProfile = async (req, res, next) => {
  try {
    await User.findByIdAndDelete(req.user.id);

    res.status(200).json({
      message: "User profile deleted successfully",
    });
  } catch (err) {
    next(err);
  }
};


export const createUserCarListing = async (req, res, next) => {
    try {
        // 1. Body se data nikalo
        const {
            sellerName, sellerMobile, sellerEmail,
            city, pincode,
            make, model, variant, year, kmDriven,
            fuelType, transmission,registrationCity,
            registrationNumber, noOfOwners, expectedPrice, description
        } = req.body;
 
        // 2. Validation (Jo fields "Y" hain image mein)
        if (!sellerName || !sellerMobile || !city || !make || !model || !year || !kmDriven || !fuelType || !transmission) {
            throw new ApiError(400, "All required fields marked with * must be filled.");
        }
 
        // 3. Files Handling (Images & Documents)
        // req.files['images'] aur req.files['documents'] multer se aayenge
        let imageUrls = [];
        let docUrls = [];
 
        // Upload Car Photos
        if (req.files && req.files.images && req.files.images.length > 0) {
             // Promise.all use kar rahe hain taaki saari images parallel upload ho jayein
             imageUrls = await Promise.all(
                req.files.images.map(async (file) => {
                    return await uploadFileToSpaces(file, "car-images");
                })
            );
        } else {
            throw new ApiError(400, "At least one car photo is required.");
        }
 
        // Upload Car Documents (agar user ne upload kiye hain)
        if (req.files && req.files.documents && req.files.documents.length > 0) {
            docUrls = await Promise.all(
                req.files.documents.map(async (file) => {
                    return await uploadFileToSpaces(file, "car-documents");
                })
            );
        }
 
        // 4. Franchise Allocation Logic (Optional abhi ke liye)
        // Future mein yahan logic aayega: Find Franchise where franchise.pincode === req.body.pincode
        // Abhi ke liye hum null chhod rahe hain ya manually admin assign karega.
        const assignedFranchise = null;
 
        // 5. Database mein Save karna
        const newCar = await carModel.create({
            sellerName,
            sellerMobile,
            sellerEmail,
            city,
            pincode,
            make,
            model,
            variant,
            year,
            kmDriven,
            fuelType,
            transmission,
            registrationNumber,
            noOfOwners,
            expectedPrice,
            description,
            registrationCity  ,    // 🔥 NEW FIELD
            images: imageUrls,      // S3 Links array
            documents: docUrls,     // S3 Links array
            listedBy: req.user.id, // Auth middleware se aayega
            franchise: assignedFranchise,
            status: 'pending_verification'
        });
 
        return res.status(201).json({
            success: true,
            message: "Car listing submitted successfully! Pending verification.",
            car: newCar
        });
 
    } catch (error) {
        next(error);
    }
};
 