
// import Inquiry from "../Models/inquiry.model.js";
// import carModel from "../Models/car.model.js";
// import Deal from "../Models/deal.model.js";

// export const startDeal = async (req, res, next) => {
//   try {
//     const { inquiryId } = req.body;

//     // 🔥 Terminal output ke hisaab se key 'id' hai
//     const currentUserId = req.user.id; 

//     if (!currentUserId) {
//       return res.status(401).json({ message: "User not authenticated correctly" });
//     }

//     const inquiry = await Inquiry.findById(inquiryId).populate("car");
//     if (!inquiry) return res.status(404).json({ message: "Inquiry not found" });

//     // Check agar deal pehle se hai
//     const existingDeal = await Deal.findOne({ inquiry: inquiryId });
//     if (existingDeal) return res.status(400).json({ message: "Deal already exists" });

//     const deal = await Deal.create({
//       inquiry: inquiryId,
//       car: inquiry.car._id,
//       franchise: currentUserId, // ✅ Fixed: 'id' key use kiya
//       buyer: inquiry.buyer,
//       initialPrice: inquiry.car.expectedPrice,
//       status: "negotiating",
//       negotiation: [{
//         sender: currentUserId,
//         senderRole: "franchise",
//         offeredPrice: inquiry.car.expectedPrice,
//         message: "Initial offer from Franchise"
//       }]
//     });

//     res.status(201).json({ success: true, data: deal });
//   } catch (error) { 
//     console.error("Deal Create Error:", error);
//     next(error); 
//   }
// };


// export const makeOffer = async (req, res, next) => {
//   try {
//     // 1. Deal ID nikalne ke do raaste (Body ya URL)
//     const dealId = req.body.dealId || req.params.dealId;
//     const { offeredPrice, message } = req.body;

//     if (!dealId) {
//       return res.status(400).json({ success: false, message: "Deal ID bhejna zaroori hai" });
//     }

//     // 2. Token se User ID nikalna (Aapke token mein 'userId' hai)
//     const currentUserId = req.user.userId || req.user.id || req.user._id;

//     const deal = await Deal.findById(dealId);
//     if (!deal) return res.status(404).json({ message: "Deal nahi mili" });
//      if (deal.status === "sold") {
//       return res.status(403).json({
//         success: false,
//         message: "Deal already sold. Negotiation is closed."
//       });
//     }
//     // 3. ROLE CHECK LOGIC (Ye decide karega ki message kisne bheja)
//     let role = "";
//     if (currentUserId.toString() === deal.buyer.toString()) {
//       role = "buyer";      // Agar token buyer ka hai
//     } else if (currentUserId.toString() === deal.franchise.toString()) {
//       role = "franchise";  // Agar token franchise ka hai
//     } else {
//       return res.status(403).json({ message: "Aap is deal ka hissa nahi hain" });
//     }

//     // 4. Negotiation History mein message add karna
//     deal.negotiation.push({
//       sender: currentUserId,
//       senderRole: role,
//       offeredPrice: offeredPrice || deal.initialPrice, // Agar price nahi di toh purani hi rahegi
//       message: message,
//       createdAt: new Date()
//     });

//     await deal.save();

//     res.status(200).json({ 
//       success: true, 
//       message: `${role === "buyer" ? "Buyer" : "Franchise"} ka message bhej diya gaya`, 
//       data: deal 
//     });

//   } catch (error) { 
//     console.error(error);
//     next(error); 
//   }
// };

// export const finalizeDeal = async (req, res, next) => {
//   try {
//     const { dealId, finalPrice, paymentMethod } = req.body;
    
//     // Aapke token ke hisaab se 'id' use karte hain
//     const currentUserId = req.user.id || req.user.userId || req.user._id;

//     if (!dealId) return res.status(400).json({ message: "Deal ID is required" });

//     const deal = await Deal.findById(dealId);
//     if (!deal) return res.status(404).json({ message: "Deal not found" });

//     // Franchise Check: Sirf wahi franchise finalize kar sakta hai jiski deal hai
//     if (deal.franchise.toString() !== currentUserId.toString()) {
//       return res.status(403).json({ message: "Only assigned Franchise can finalize this deal" });
//     }

//     // Check agar pehle hi sold toh nahi hai?
//     if (deal.status === "sold") {
//         return res.status(400).json({ message: "This deal is already finalized and sold!" });
//     }

//     // 1. Deal details update
//     deal.finalAgreedPrice = finalPrice;
//     deal.status = "sold";
//     deal.paymentMethod = paymentMethod;
//     deal.paymentStatus = "completed";
//     deal.closureDate = new Date(); // Date bhi save karlo kab biki
    
//     await deal.save();

//     // 2. Car ko "Sold" mark karo taaki search mein na dikhe
//     await carModel.findByIdAndUpdate(deal.car, { status: "sold" });

//     // 3. (Optional) Inquiry ko bhi "Closed" mark kar sakte ho yahan
//     await Inquiry.findByIdAndUpdate(deal.inquiry, { status: "sold" });

//     res.status(200).json({ 
//         success: true, 
//         message: "Car Sold Successfully! Deal Closed.",
//         data: deal
//     });
    
//   } catch (error) { 
//     console.error(error);
//     next(error); 
//   }
// };
// //   try {
// //     const { dealId, offeredPrice, message } = req.body;
// //     const deal = await Deal.findById(dealId);

// //     if (!deal) return res.status(404).json({ message: "Deal not found" });

// //     // Determine Role (Check if requester is buyer or franchise)
// //     let role = "";
// //     if (req.user._id.toString() === deal.buyer.toString()) role = "buyer";
// //     else if (req.user._id.toString() === deal.franchise.toString()) role = "franchise";
// //     else return res.status(403).json({ message: "Unauthorized" });

// //     // Add to history
// //     deal.negotiation.push({
// //       sender: req.user._id,
// //       senderRole: role,
// //       offeredPrice: offeredPrice,
// //       message: message
// //     });

// //     await deal.save();
// //     res.status(200).json({ success: true, message: "Offer submitted", data: deal });
// //   } catch (error) { next(error); }
// // };


// // export const finalizeDeal = async (req, res, next) => {
// //   try {
// //     const { dealId, finalPrice, paymentMethod } = req.body;
// //     const deal = await Deal.findById(dealId);

// //     if (deal.franchise.toString() !== req.user._id.toString()) {
// //       return res.status(403).json({ message: "Only Franchise can finalize the deal" });
// //     }

// //     deal.finalAgreedPrice = finalPrice;
// //     deal.status = "sold";
// //     deal.paymentMethod = paymentMethod;
// //     deal.paymentStatus = "completed";
// //     await deal.save();

// //     // Car ka status update karo
// //     await Car.findByIdAndUpdate(deal.car, { status: "sold" });

// //     res.status(200).json({ success: true, message: "Car Sold Successfully!" });
// //   } catch (error) { next(error); }
// // };











import Inquiry from "../Models/inquiry.model.js";
import Car from "../Models/car.model.js";
import Deal from "../Models/deal.model.js";
import { getIO } from "../Services/socket.js";
 
export const startDeal = async (req, res) => {
  try {
    const io = getIO();
    const { inquiryId } = req.body;
    const userId = req.user.id;
 
    const inquiry = await Inquiry.findById(inquiryId).populate("car");
    if (!inquiry) {
      return res.status(404).json({ message: "Inquiry not found" });
    }
 
    // ✅ STEP 1: Check existing deal for this inquiry
    const existingDeal = await Deal.findOne({ inquiry: inquiryId });
 
    if (existingDeal) {
      return res.status(400).json({
        message: "Deal already exists",
        dealId: existingDeal._id
      });
    }
 
    // ✅ STEP 2: Create new deal
    const deal = await Deal.create({
      inquiry: inquiryId,
      car: inquiry.car._id,
      franchise: userId,
      buyer: inquiry.buyer,
      initialPrice: inquiry.car.expectedPrice,
      status: "negotiating",
      negotiation: []
    });
 
    io.to(deal._id.toString()).emit("dealStarted", { dealId: deal._id });
 
    res.json({ success: true, data: deal });
 
  } catch (error) {
    console.error("Start Deal Error:", error);
    res.status(500).json({ message: error.message });
  }
};
 
 
export const makeOffer = async (req, res) => {
  try {
    const io = getIO();
    const { dealId, offeredPrice, message } = req.body;
    const userId = req.user.id;
 
    const deal = await Deal.findById(dealId);
    if (!deal) return res.status(404).json({ message: "Deal not found" });
 
    const role = deal.franchise.toString() === userId.toString() ? "franchise" : "buyer";
 
    const newMessage = { sender: userId, senderRole: role, offeredPrice, message, timestamp: new Date() };
    deal.negotiation.push(newMessage);
    await deal.save();
 
    // Broadcast to the room
    io.to(dealId.toString()).emit("newOffer", newMessage);
 
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
 
 
export const finalizeDeal = async (req, res, next) => {
  try {
    const io = getIO();
    const { dealId, finalPrice, paymentMethod } = req.body;
    const userId = req.user.id;
 
    const deal = await Deal.findById(dealId);
    if (!deal) return res.status(404).json({ message: "Deal not found" });
 
    if (deal.franchise.toString() !== userId.toString()) {
      return res.status(403).json({ message: "Only franchise can finalize deal" });
    }
 
    deal.finalAgreedPrice = finalPrice;
    deal.paymentMethod = paymentMethod;
    deal.status = "sold";
    deal.paymentStatus = "completed";
    deal.closureDate = new Date();
 
    await deal.save();
 
    await Car.findByIdAndUpdate(deal.car, { status: "sold" });
    await Inquiry.findByIdAndUpdate(deal.inquiry, { status: "converted" });
 
    io.to(dealId.toString()).emit("dealFinalized", {
      dealId,
      finalPrice,
      status: "sold",
    });
 
    res.json({ success: true, message: "Deal finalized", data: deal });
  } catch (err) {
    next(err);
  }
};
 
export const getDealDetails = async (req, res) => {
  try {
    const { dealId } = req.params;
 
    const deal = await Deal.findById(dealId)
      .populate("negotiation.sender", "fullName role");
 
    if (!deal) {
      return res.status(404).json({ message: "Deal not found" });
    }
 
    res.json({
      success: true,
      data: deal
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
 
 