

import mongoose from "mongoose";
import bcrypt from "bcryptjs";

const franchiseSchema = new mongoose.Schema(
  {
  
        owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', },
    franchiseName: { type: String, required: true },
  
    fullName: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    phone: { type: String, required: true },
    password: { type: String, required: true, select: false },


    franchiseName: { type: String, required: true },

    franchiseCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,     
    },

    gstNumber: { type: String },

    address: { type: String, required: true },
      // A franchise can manage multiple pincodes
    managedPincodes: [{ type: String, required: true }],
    

    country: { type: mongoose.Schema.Types.ObjectId, ref: "Country" },
    state: { type: mongoose.Schema.Types.ObjectId, ref: "State" },
    city: { type: mongoose.Schema.Types.ObjectId, ref: "City" },


    bankAccountNumber: { type: String },
    ifscCode: { type: String },
    commissionPercent: { type: Number, default: 0 },

 
    assignedDealers: [
      { type: mongoose.Schema.Types.ObjectId, ref: "Dealer" }
    ],

   
    profileImage: { type: String },
       kycDocuments: [
      {
        type: String, 
      },
    ],


 
    role: { type: String, default: "franchise" },
    
   verificationStatus: {
      type: String,
      enum: ["pending", "verified"],
      default: "pending",
    },

    paymentStatus: {
      type: String,
      enum: ["pending", "paid"],
      default: "pending",
    },

        // Franchise Model me add karo
      listingLimit: {
        type: Number,
        default: 3, // 🎯 free listings
      },

      usedListings: {
        type: Number,
        default: 0,
      },

      activePackage: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Package",
        default: null,
      },

    status: {
      type: String,
      enum: ["inactive", "active"],
      default: "inactive",
    },
  },
  { timestamps: true }
);


franchiseSchema.pre("save", async function () {
  if (!this.isModified("password")) return;  // no next()
  this.password = await bcrypt.hash(this.password, 10);
});


franchiseSchema.methods.comparePassword = async function (plain) {
  return await bcrypt.compare(plain, this.password);
};


export default mongoose.model("Franchise", franchiseSchema);
